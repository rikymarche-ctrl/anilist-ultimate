const a={AUTH_LOGIN:"auth:login",AUTH_LOGOUT:"auth:logout",AUTH_STATUS:"auth:status"},t="anilist_auth_token",s="anilist_user_cache";export{t as A,a as M,s as a};
